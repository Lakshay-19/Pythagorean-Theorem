﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    //Lakshay Punj
    //March 7, 2019
    //Pythagorean Theorem
namespace PythagoreanTheorem
{
    class Program
    {
        static void Main(string[] args)
        {
            //Intro Inputs

            Console.WriteLine("Enter the first side length");
            double Side1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the second side length:");
            double Side2 = double.Parse(Console.ReadLine());

            //Calculation process

            double Hypotenuse = Math.Sqrt(Side1 * Side1 + Side2 * Side2);
            Console.WriteLine("The hypotenuse is " + Hypotenuse);


            Console.ReadKey();




        }
    }
}
